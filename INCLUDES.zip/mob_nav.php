<nav>
    <img id="ham" src="./IMAGE/ant-design_menu-outlined.png" alt="">
    <img src="./IMAGE/logo mobile.png" alt="">
    <img id="avatar" src="./image/ooui_user-avatar mobile.png" alt="">
</nav>