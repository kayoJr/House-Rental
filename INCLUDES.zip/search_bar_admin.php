<div class="search search-admin" id="search">
<div class="container">
    <form action="./admin-properties.php" method="GET">
        <select name="type" id="type" required>
            <option value="" disabled selected>Type</option>
            <option value="all">All</option>
            <option value="approved">Approved</option>
            <option value="pending">Pending</option>
        </select>
        <input type="submit" value="SEARCH" name="submit" class="btn btn-secondary">
    </form>
</div>
</div>